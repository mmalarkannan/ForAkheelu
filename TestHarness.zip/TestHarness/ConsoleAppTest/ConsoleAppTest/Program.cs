﻿using System;

namespace ConsoleAppTest
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");

            Console.WriteLine($"Guid 1: {Guid.NewGuid()}" );
            Console.WriteLine($"Guid 2: {Guid.NewGuid()}");
            Console.WriteLine($"Guid 3: {Guid.NewGuid()}");
            Console.WriteLine($"Guid 4: {Guid.NewGuid()}");
            Console.WriteLine($"Guid 5: {Guid.NewGuid()}");
            Console.WriteLine($"Guid 6: {Guid.NewGuid()}");
            Console.WriteLine($"Guid 7: {Guid.NewGuid()}");
            Console.WriteLine($"Guid 8: {Guid.NewGuid()}");
            Console.WriteLine($"Guid 9: {Guid.NewGuid()}");
            Console.WriteLine($"Guid 10: {Guid.NewGuid()}");
            Console.WriteLine($"Guid 11: {Guid.NewGuid()}");
            Console.WriteLine($"Guid 12: {Guid.NewGuid()}");
            Console.WriteLine($"Guid 13: {Guid.NewGuid()}");
            Console.WriteLine($"Guid 14: {Guid.NewGuid()}");

            //ApplyDiscounts();
        }

        public static void ApplyDiscounts()
        {
            int quantity = 0;
            quantity += quantity / 2;

            Console.WriteLine($"Total Quantity: {quantity}");
        }
    }
}
